module.exports = require('./lib/VCard');
